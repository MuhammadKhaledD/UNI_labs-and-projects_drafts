﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace students_example1
{
    public partial class Form1 : Form
    {
        bool enable_changing = true;
        bool label_hidden = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text!="")
            label1.Text = textBox1.Text;
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
            //Cause if we have the boolean set to true so now we have to disable the button and make change the button text to make the user enable it in the next press
            if (enable_changing)
            {
                button2.Text = "Enable changing label";
                button1.Enabled = false;
            }
            else
            {
                //now if we are here this means the button of changing is disabled so we enable it and change the text of the controlling button (button2) to disable (cause now the button1 is enabled)
                button2.Text = "Disable changing label";
                button1.Enabled = true;
            }
            enable_changing = !enable_changing;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (label_hidden)
            {
                label1.Visible = true;
                button3.Text = "Hide label";
            }
            else
            {
                label1.Visible = false;
                button3.Text = "Show label";
            }
            label_hidden=!label_hidden;

        }
    }
}
